import React from 'react';
import { createRoot } from 'react-dom/client';
import { ArrowRight, Bot, Code2, Server, ShieldCheck, Globe2, Activity } from 'lucide-react';
import { motion } from 'framer-motion';
import './styles.css';

const fadeUp = {
  initial: { opacity: 0, y: 28 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: '-80px' },
  transition: { duration: 0.7, ease: 'easeOut' }
};

const services = [
  {
    no: '01',
    title: 'AI & Automation',
    headline: 'Intelligent systems. Real business impact.',
    icon: Bot,
    points: ['AI Chatbots & Assistants', 'Process Automation', 'AI Support Systems', 'Smart Reporting & Analytics']
  },
  {
    no: '02',
    title: 'Custom Software',
    headline: 'Custom software, built around you.',
    icon: Code2,
    points: ['Web & Mobile Applications', 'Dashboards & Reporting', 'Business Platforms', 'System Integrations']
  },
  {
    no: '03',
    title: 'Infrastructure',
    headline: 'Strong infrastructure. Secure future.',
    icon: Server,
    points: ['Servers & Storage', 'Cloud Infrastructure', 'Network Solutions', 'Cyber Security']
  }
];

const about = [
  ['01', 'Client Focused', 'We prioritize satisfaction, reliability, and long-term partnerships.'],
  ['02', 'Reliable Delivery', 'Timely delivery of tailored solutions at competitive value.'],
  ['03', 'Expert Team', 'A dedicated team driving measurable results for our clients.'],
  ['04', 'Measurable Impact', 'Solutions that drive efficiency, growth and real business impact.']
];

const why = [
  ['01', 'AI + Infrastructure Expertise', 'End-to-end capabilities under one roof.'],
  ['02', 'Future-Ready Solutions', 'Scalable, secure and built for tomorrow.'],
  ['03', 'Global Outlook', 'Expanding across GCC, Europe & global markets.'],
  ['04', 'Commitment to Excellence', 'Quality, reliability and measurable results.']
];

function TechVisual({ variant = 'hero' }) {
  return (
    <div className={`visual ${variant}`}>
      <div className="orb orb-one" />
      <div className="orb orb-two" />
      <div className="grid-lines" />
      <div className="road-line" />
      <div className="chip-card floating-one"><Activity size={18}/> Smart systems</div>
      <div className="chip-card floating-two"><Globe2 size={18}/> GCC+ reach</div>
      <div className="pulse-core">E11</div>
    </div>
  );
}

function App() {
  return (
    <main>
      <header className="nav">
        <a className="brand" href="#top" aria-label="TechE11 home">
          <span className="brand-mark">E11</span>
          <span>TechE11<br/><small>Innovative Solutions LLC</small></span>
        </a>
        <nav>
          <a href="#services">Services</a>
          <a href="#ai">AI & Automation</a>
          <a href="#infrastructure">Infrastructure</a>
          <a href="#why">Why Us</a>
          <a href="#contact">Contact</a>
        </nav>
        <a className="nav-cta" href="mailto:sales@teche11.com">Let&apos;s Talk <ArrowRight size={16}/></a>
      </header>

      <section id="top" className="hero section-pad">
        <motion.div className="hero-copy" {...fadeUp}>
          <h1>Building intelligent<br/>systems that<br/>accelerate your business.</h1>
          <p>TechE11 builds AI, automation, custom software and infrastructure solutions for businesses scaling across the GCC, Africa, Europe and beyond.</p>
          <div className="hero-actions">
            <a href="#services" className="btn primary">Explore Services <ArrowRight size={18}/></a>
            <a href="#contact" className="btn ghost">Start a Project</a>
          </div>
        </motion.div>
        <motion.div className="hero-art" {...fadeUp} transition={{ duration: .85, delay: .1 }}>
          <TechVisual />
        </motion.div>
      </section>

      <section className="stats strip">
        <div><strong>24/7</strong><span>AI automation</span></div>
        <div><strong>4</strong><span>Solution pillars</span></div>
        <div><strong>GCC+</strong><span>Global reach</span></div>
        <div><strong>∞</strong><span>Scalable by design</span></div>
      </section>

      <div className="marquee"><span>AI & Automation ✦ Custom Software ✦ Cloud Infrastructure ✦ Cyber Security ✦ System Integrations ✦ Dashboards & Analytics ✦ </span><span>AI & Automation ✦ Custom Software ✦ Cloud Infrastructure ✦ Cyber Security ✦ System Integrations ✦ Dashboards & Analytics ✦ </span></div>

      <section className="about section-pad">
        <motion.div className="section-heading" {...fadeUp}>
          <p className="eyebrow">About Us</p>
          <h2>A dynamic, forward-thinking technology partner.</h2>
          <p>Strategically positioned in the UAE with deep market understanding and a strong network across the GCC, Africa, Europe and beyond — delivering solutions that empower growth and efficiency.</p>
        </motion.div>
        <div className="about-grid">
          {about.map(([no, title, text]) => <motion.article className="mini-card" key={title} {...fadeUp}><span>{no}</span><h3>{title}</h3><p>{text}</p></motion.article>)}
        </div>
      </section>

      <section id="services" className="services section-pad">
        <motion.div className="section-heading center" {...fadeUp}>
          <p className="eyebrow">Our Services</p>
          <h2>Smart solutions<br/>built to scale.</h2>
          <p>Four pillars, one partner. AI, automation, custom software and infrastructure engineered to help businesses thrive in a technology-driven landscape.</p>
        </motion.div>
        <div className="service-grid">
          {services.map((s) => {
            const Icon = s.icon;
            return <motion.article className="service-card" id={s.title === 'AI & Automation' ? 'ai' : s.title === 'Infrastructure' ? 'infrastructure' : undefined} key={s.title} {...fadeUp}>
              <div className="service-image"><Icon size={44}/><span>{s.headline}</span></div>
              <div className="service-body"><p>{s.no} / {s.title}</p><h3>{s.headline}</h3><ul>{s.points.map(p => <li key={p}>{p}</li>)}</ul><a href="#contact">End-to-end delivery <ArrowRight size={16}/></a></div>
            </motion.article>
          })}
        </div>
      </section>

      <section className="impact section-pad">
        <motion.div className="impact-copy" {...fadeUp}>
          <p className="eyebrow">Impact</p>
          <h2>Solutions that drive efficiency, growth and measurable results.</h2>
        </motion.div>
        <div className="impact-grid">
          <div><strong>24/7</strong><b>Automation</b><span>Never stops working</span></div>
          <div><strong>↑</strong><b>Efficiency</b><span>Reduce manual workload</span></div>
          <div><strong>◆</strong><b>Decisions</b><span>Data-driven insights</span></div>
          <div><strong>∞</strong><b>Scalable</b><span>Built for growth</span></div>
        </div>
      </section>

      <section id="why" className="why section-pad">
        <div className="split-visual"><TechVisual variant="summit"/><p>Path to the summit</p></div>
        <motion.div className="why-copy" {...fadeUp}>
          <p className="eyebrow">Why TechE11</p>
          <h2>Your partner for the long accelerate.</h2>
          <p className="eyebrow">Why Us</p>
          <h2>Technology, expertise, and commitment — combined.</h2>
          <div className="why-list">
            {why.map(([no, title, text]) => <article key={title}><span>{no}</span><div><h3>{title}</h3><p>{text}</p></div><ArrowRight size={18}/></article>)}
          </div>
        </motion.div>
      </section>

      <section id="contact" className="contact section-pad">
        <motion.div {...fadeUp}>
          <p className="eyebrow">Let&apos;s Build</p>
          <h2>Let&apos;s build<br/>the future.</h2>
          <p>Ready to accelerate your business? Reach out and let&apos;s design something that creates real impact.</p>
        </motion.div>
        <div className="contact-cards">
          <a href="tel:+971502007966"><span>Call</span><strong>+971 50 200 7966</strong><em>Connect <ArrowRight size={16}/></em></a>
          <a href="mailto:sales@teche11.com"><span>Email</span><strong>sales@teche11.com</strong><em>Connect <ArrowRight size={16}/></em></a>
          <a href="https://www.teche11.com"><span>Web</span><strong>www.teche11.com</strong><em>Connect <ArrowRight size={16}/></em></a>
        </div>
      </section>

      <footer><span>United Arab Emirates</span><span>© 2026 TechE11 Innovative Solutions LLC</span><span>Building intelligent systems · UAE</span></footer>
    </main>
  );
}

createRoot(document.getElementById('root')).render(<App />);
